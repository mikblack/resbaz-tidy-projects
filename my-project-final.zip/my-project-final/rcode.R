# Read in data
a = read.csv('car-speeds.csv')

head(a)

dim(a)


table(a$State)

table(a$Color)

table(a$Color, a$State)

hist(a$Speed)

# Make plot
boxplot(a$Speed ~ a$Color)

# Make other plot
boxplot(a$Speed ~ a$State)

# Write plots to file
png(file="plot1.png")
boxplot(a$Speed ~ a$State)
#boxplot(a$Speed ~ a$Color)
dev.off()

png(file="plot2.png")
hist(a$Speed)
dev.off()

